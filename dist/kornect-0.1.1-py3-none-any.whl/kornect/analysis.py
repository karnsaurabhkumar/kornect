# Libraries
# Following libraries are used to make the ppt2vid
import sys
import subprocess
import pkg_resources


def install_pypackages(requirements):
    return 1
